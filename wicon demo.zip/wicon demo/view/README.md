Creative Gooey Effects
=========

Practical examples of how to apply the Gooey effect by Lucas Bebber

[Article on Codrops](http://tympanus.net/codrops/?p=23487)

[Demo](http://tympanus.net/Development/CreativeGooeyEffects/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

Follow us: [Twitter](http://www.twitter.com/codrops), [Facebook](http://www.facebook.com/pages/Codrops/159107397912), [Google+](https://plus.google.com/101095823814290637419), [GitHub](https://github.com/codrops), [Pinterest](http://www.pinterest.com/codrops/)

[© Codrops 2015](http://www.codrops.com)


