<?php

include_once __DIR__ . "/vendor/autoload.php";

use Dompdf\Dompdf;

$pdf = new Dompdf;

$pdf->loadhtml('<h1>Hello World..!!</h1>');

$pdf->render();
$pdf->stream();

?>