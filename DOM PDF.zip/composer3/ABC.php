<?php

	class ABC 
	{
		function __construct() 
		{
			print "In BaseClass constructor\n";
		}
	}

?>